package org.jcvi.psette;


public class ETstrain {
	public double distancefrom,ycord;
	public String seq;
	public String strain_name;
	public String accesion_number;
	public String geographic_location;
	public String host;
	public int year,xcord;
}



