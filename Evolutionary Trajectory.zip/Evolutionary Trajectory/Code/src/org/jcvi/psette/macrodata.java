package org.jcvi.psette;

public class macrodata {


	public  String host,country,totalhost,totalcountry,temphoststor,tempcountrystor;
	public int hostcounter,countrycounter,temphostcount,tempcountrycount;
}
